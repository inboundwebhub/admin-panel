$(document).ready(function() {

$('#next1').click(function () {
   

    var data = new FormData();
    data.append('f_name', $('#f_name').val());
    data.append('m_name', $('#m_name').val());
    data.append('l_name', $('#l_name').val());
    data.append('gender', $('input[name="gender"]:checked').val());
    data.append('email', $('#email').val());
    data.append('password', $('#password').val());

    $('#profile_pic').change(
        function () {
            var fileExtension = ['jpeg', 'jpg', 'pdf'];
            if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                $(this).next().html('only jpeg, jpg and pdf format file allowed');
                return false; }
    });
    
 

    $("#form1").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
           f_name: "required",
        //    m_name: "required",
        //    l_name: "required",
        //    gender: "required",
        //    email: { required: true,
        //     email: true },
        //    required: true,
            password: {
                required: true,
               
                minlength: 8
            },
        //    "profile_pic[]": {required : true}
        },
        
     
       messages: {
           f_name: "Please enter your firstname",
        //    m_name: "Please enter your middlename",
        //    l_name: "Please enter your lastname",
        //    gender: "Please select gender",
        //    email: "Please enter your valid email address",
           password: "Your password must be at least 8 characters. and it must contain letters (lowercase and uppercase) ",
        // profile_pic: ""
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
       

        submitHandler: function () {
            // form.submit();
         
            return false;
        }
   
    });

    $.validator.addMethod("pwdcheck", function(value) {
        return /[A-Z]/.test(value) &&
               /\d/.test(value) && 
               /[=!\-@._*\$\#\%\^\&\(\)\~\`\<\>\/\?\\\|\{\}\[\]\;\:\'\"\,\+]/.test(value)
    });

    if($('#form1').valid())
    { 
        $.ajax({

            type: "POST",
               
            url: 'http://127.0.0.1:8000/profile/insert_personal_details',
            processData: false,
            contentType: false,
           
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });
            var val =  $(this).parent().parent().parent().parent().next().attr('id');
            alert(val)
            if(val == 'profile')
            { 
                $('#profile_tab').addClass('active');
                $('a.active:first').removeClass('active');
            
            }
            else
            {
                $("a.active").parent().next().children().addClass('active');
                $("a.active:first").parent().children().removeClass('active');
            }
            var res = $("a.active").attr("href");
            
            $('#'+val).addClass('active');
            var val1 = $(this).parent().parent().parent().parent().attr('id');
        
            $('#'+val1).removeClass('active');  
        return true;
    }
    else
    {
        return false;
    }
});


$('#next2').click(function () {

    var data = new FormData();
    data.append('b_date', $('#b_date').val());
    data.append('b_group', $('#b_group').val());
    data.append('m_status', $('#select option:selected').val());
    data.append('dl_number', $('#dl_number').val());
    data.append('pass_num', $('#pass_num').val());
    data.append('bio', $('#bio').val());

    $("#form2").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        b_date: "required",
        b_group: "required",
        m_status: "required",
        dl_number: "required",
        pass_num: "required",
        bio: "required",
         
       },
       messages: {
        b_date: "Please enter your birth date",
        b_group: "Please enter your blood group",
        m_status: "Please enter your Marital Status",
        dl_number: "Please enter your Driving License number",
        pass_num: "Please enter your Passport number",
        bio: "Please enter your Bio",
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
        
            // form.submit();
           
            return false;
        }
   
    });

    if($('#form2').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_general_details',
            processData: false,
            contentType: false,
           
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
       
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }

})


$('#next3').click(function () {

    var data = new FormData();
    data.append('c_address', $('#c_address').val());
    data.append('c_city', $('#c_city').val());
    data.append('c_state', $('#c_state').val());
    data.append('c_zipcode', $('#c_zipcode').val());
    data.append('c_number', $('#c_number').val());
    data.append('l_numbe', $('#l_numbe').val());
    data.append('skypeid', $('#skypeid').val());


    $("#form3").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        c_address: "required",
        // c_city: "required",
        // c_state: "required",
        // c_zipcode: "required",
        // c_number: "required",
        // l_number: "required",
        // skypeid: "required",
         
       },
       messages: {
        c_address: "Please enter your current address",
        // c_city: "Please enter your current city",
        // c_state: "Please enter your current state",
        // c_zipcode: "Please enter your current zipcode",
        // c_number: "Please enter your contact number",
        // l_number: "Please enter your local number",
        // skypeid: "Please enter your company skypeid",
  
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
          
            return false;
        }
   
    });

    if($('#form3').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_contact_details_current',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
       
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }

})


$('#next4').click(function () {

    var data = new FormData();
    data.append('p_address', $('#p_address').val());
    data.append('p_city', $('#p_city').val());
    data.append('p_state', $('#p_state').val());
    data.append('p_zipcode', $('#p_zipcode').val());
    data.append('p_number1', $('#p_number1').val());
    data.append('p_number2', $('#p_number2').val());
    data.append('p_emailid', $('#p_emailid').val());
    data.append('p_skypeid', $('#p_skypeid').val());


    $("#form4").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        p_address: "required",
        p_city: "required",
        p_state: "required",
        p_zipcode: "required",
        p_number1: "required",
        p_number2: "required",
        p_emailid: { required: true,
                 email: true },
        p_skypeid: "required"
         
       },
       messages: {
        p_address: "Please enter your permanent address",
        p_city: "Please enter your permanent city",
        p_state: "Please enter your permanent state",
        p_zipcode: "Please enter your permanent zipcode",
        p_number1: "Please enter your parent contact number1",
        p_number2: "Please enter your parent contact number2",
        p_emailid: "Please enter your personal emailid",
        p_skypeid: "Please enter your personal skypeid",
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
           
            return false;
        }
   
    });

    if($('#form4').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_contact_details_permanent',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
      
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }
})


$('#next5').click(function () {


    var data = new FormData();
    data.append('name', $('#name').val());
    data.append('relation', $('#relation').val());
    data.append('number', $('#number').val());
    data.append('address', $('#address').val());


    $("#form5").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        name: "required",
        relation: "required",
        number: "required",
        address: "required"
         
       },
       messages: {
        name: "Please enter name",
        relation: "Please enter relation",
        number: "Please enter contact number",
        address: "Please enter your address",
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
           
            return false;
        }
   
    });

    if($('#form5').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_emergency_contact_details',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
        alert(val)
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }

})

$('#next6').click(function () {

    var select_education = [];
    $(".select_education option:selected").each(function () {

        select_education.push($(this).val());

    })

    var degree = [];
    $("input[name='degree[]']").each(function () {
        degree.push($(this).val());
    })


    var university = [];
    $("input[name='university[]']").each(function () {
        university.push($(this).val());
    })


    var passing_year = [];
    $("input[name='passing_year[]']").each(function () {
        passing_year.push($(this).val());
    })


    var grade = [];
    $("input[name='grade[]']").each(function () {
        grade.push($(this).val());
    })


    var checkbox = [];
    $('.checkbox').each(function () {

        if ($(this).prop('checked')) {
            checkbox.push($(this).val())
        }

    })
    // if(select_education.length < 0 )
    var data = new FormData();
    data.append('select', select_education);
    data.append('degree', degree);
    data.append('university', university);
    data.append('passing_year', passing_year);
    data.append('grade', grade);
    data.append('tags', $('#tags-input').val());
    data.append('language', checkbox);

    $("#form6").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        
        "degree[]": "required",
        "university[]": "required",
        "passing_year[]": "required",
        "grade[]": "required",
        "tags[]": "required",
        "language[]": "required",
         
        
         
       },
       messages: {
      
        degree: "Please enter your degree",
        university: "Please enter your university",
        passing_year: "Please enter your passing-year",
        grade: "Please enter your grade",
        tags: "Please enter your skills",
        language: "Please enter language",
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
          
            return false;
        }
   
    });

    if($('#form6').valid())
    {  

        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_qualification_details',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');

        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }

})


$('#next8').click(function () {

    var duration = [];
    $("input[name='duration[]']").each(function () {
        duration.push($(this).val());
    })

    var c_name = [];
    $("input[name='c_name[]']").each(function () {
        c_name.push($(this).val());
    })


    var company_number = [];
    $("input[name='company_number[]']").each(function () {
        company_number.push($(this).val());
    })


    var company_address = [];
    $(".company_address").each(function () {
        company_address.push($(this).val());
    })
  

    var data = new FormData();
    data.append('duration', duration);
    data.append('c_name', c_name);
    data.append('c_number', company_number);
    data.append('c_address', company_address);


    $("#form8").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        "duration[]": "required",
       "c_name[]": "required",
        "company_number[]": "required",
        "company_address[]": "required",
         
       },
       messages: {
        duration: "Please enter duration of comapany",
        c_name: "Please enter your company name",
        company_number: "Please enter your company number",
        company_address: "Please enter your company address",
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
         
            return false;
        }
   
    });

    if($('#form8').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_work_experiance',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
      
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }

})


$('#next9').click(function () {

    var data = new FormData();

    data.append('bank_name', $('#bank_name').val());
    data.append('branch_name', $('#branch_name').val());
    data.append('account_number', $('#account_number').val());


    $("#form9").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        bank_name: "required",
        branch_name: "required",
        account_number: "required",
         
       },
       messages: {
        bank_name: "Please enter your bank name",
        branch_name: "Please enter your branch name",
        account_number: "Please enter your account number",
  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
       
            return false;
        }
   
    });

    if($('#form9').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_bank_details',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });


        var val =  $(this).parent().parent().parent().parent().next().attr('id');
       
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        return true;
    }
    else
    {
        return false;
    }
})



$('#next10').click(function (e) {
    e.preventDefault();
   // var length = $("input[name='attach_file[]']")[0].length;


    var attach_file = [];
    $(".attach_file").each(function () {
       attach_file.push($(this)[0].files[0]);
    })

    var data = new FormData();

    data.append('profile_pic', $("input[name='profile_pic']").prop('files')[0]);

    for (var i = 0; i < attach_file.length; i++) {
        data.append('attach_file[]', attach_file[i]);
    }



    $("#form10").validate({
        //  e.preventDefault();
       ignore: ":hidden",
       rules: {
        "attach_file[]":{ required: true,
                   
                    },
       },
       messages: {
        attach_file:""

  
       },
    //    errorPlacement: function (error, element) {
    //      console.log(error.text());
    //  },
   

        submitHandler: function () {
            // form.submit();
         
            return false;
        }
   
    });

    if($('#form10').valid())
    {  
        $.ajax({

            type: 'post',
            url: 'http://127.0.0.1:8000/profile/insert_file_details',
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: data,
            success: function (data) {
                console.log(data);
            },
            error: function (errResponse) {
                console.log(errResponse);
            }

        });

        $('#div1').fadeIn("slow");
        $('#div1').fadeOut(4000);
        return true;
    }
    else
    {
        return false;
    }


  });

function next()
{                                           // next button jquery code
          //  e.preventDefault();
        var val =  $(this).parent().parent().parent().parent().next().attr('id');
     
        if(val == 'profile')
        { 
            $('#profile_tab').addClass('active');
            $('a.active:first').removeClass('active');
        
        }
        else
        {
            $("a.active").parent().next().children().addClass('active');
            $("a.active:first").parent().children().removeClass('active');
        }
        var res = $("a.active").attr("href");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().prev().attr('id');
       
         $('#'+val1).removeClass('active');
    }


    $('.back').click(function(){                                           // back button jquery code
       
        var val =  $(this).parent().parent().parent().parent().prev().attr('id');
        
        $("a.active").parent().prev().children().addClass('active');
        $("a.active").parent().next().children().removeClass("active");
        
        $('#'+val).addClass('active');
        var val1 = $(this).parent().parent().parent().parent().attr('id');
     
        $('#'+val1).removeClass('active');
        
      });

})