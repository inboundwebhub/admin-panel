
$(document).ready(function(){     
       
    var tagInputEle = $('#tags-input');
    tagInputEle.tagsinput();
   

    $('.add_more').click(function(){
       var val = $('.details').html();
      
       $('.append_details').append("<div>"+val+"<div class='experiance'><a href='javascript:void(0)' class='qualification_delete'>delete</a></div></div>");
       //$('.append_details').append("<div><a href = 'javascript:void(0)' class='delete_edu_det'>delete</a></div>");
    })

    $(document).on('click', '.qualification_delete', function() {
      $(this).parent().parent().remove();
    });


    $(".attachment_add_more").click(function(){

       var val =  $('.attachment_details').html();
       $('.append_attachment').append("<div>"+val+"<div><a href='javascript:void(0)' class='attachment_delete'>delete</a></div></div>");
    })

    $(document).on('click', '.attachment_delete', function() {
      $(this).parent().parent().remove();
    });


    $(".experience_add_more").click(function(){
       
      var val = $(".experiance_details").html();
      $('.experiance_add_details').append("<div>"+val+"<div class='experiance'><a href='javascript:void(0)' class='experience_delete'>delete</a></div></div>");
    })


    $('.experiance_add_details').on('click', '.experience_delete', function() {
        $(this).parent().parent().remove();
   });

   
  
 

})



